# NoFasel Scrapper

Library that provides movie and series sources.

## Contributing

Thanks for taking the time to contribute!

#### Prerequisites

Before you start, please note that the ability to use following technologies is **required**.

- Python
- Web scraping or JSON API

## DMCA disclaimer

The developers of this application does not have any affiliation with the content available in the app. It is collecting
from the sources freely available through any web browser.

<h4 align='center'>© 2023 ツ Ahmed Badawe</h4>
